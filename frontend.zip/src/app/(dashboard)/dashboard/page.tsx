
import { redirect } from "next/navigation";
const page = () => {
  return (
    redirect('/')
  );
};

export default page;
